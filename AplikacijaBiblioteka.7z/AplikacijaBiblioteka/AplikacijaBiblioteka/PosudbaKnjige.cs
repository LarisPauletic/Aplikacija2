﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using System.IO;
using System.Collections;

namespace AplikacijaBiblioteka
{
    public partial class PosudbaKnjige : Form
    {
        static List<Posudba> ListaPosudbaKnjiga = new List<Posudba>();
        static string pathdocuments = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
        static string xmlfile = "Posudba.xml";
        static string path = Path.Combine(pathdocuments, xmlfile);

        public PosudbaKnjige()
        {
            InitializeComponent();
        }

        private void btnUpisPosudba_Click(object sender, EventArgs e)
        {
            Posudba PosudbaKnjige = new Posudba(Convert.ToInt32(txtBxIdKorisnika.Text),  Convert.ToInt32(txtBxIdKnjige.Text), dateTimePickerPosudba, dateTimePickerVracanje);
            ListaPosudbaKnjiga.Add(PosudbaKnjige);
            DialogResult dialogResult = MessageBox.Show("Želite li napraviti još jedan upis?", "Upis", MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.No)
            {
                try
                {
                    var Posudbe = XDocument.Load(path);
                    foreach (Posudba posudbe in ListaPosudbaKnjiga)
                    {
                        var PosudbaKnjiga = new XElement("Posudba",
                            new XElement("Posudba", posudbe.Datum_p),
                            new XElement("Vracanje", posudbe.Datum_v),
                            new XElement("ID Korisnika",posudbe.ID_Korisnik1),
                            new XElement("ID Knjige", posudbe.ID_Knjige1));
                        Posudbe.Root.Add(Posudbe);

                    }
                    Posudbe.Save(path);
                }
                catch (Exception ex)
                {
                    var Posudbe = new XDocument();
                    Posudbe.Add(new XElement("Posudbe"));
                    foreach (Posudba posudbe in ListaPosudbaKnjiga)
                    {
                        var PosudbaKnjiga = new XElement("Posudba",
                           new XElement("Posudba", posudbe.Datum_p),
                           new XElement("Vracanje", posudbe.Datum_v),
                           new XElement("ID Korisnika", posudbe.ID_Korisnik1),
                           new XElement("ID Knjige", posudbe.ID_Knjige1));
                        Posudbe.Root.Add(Posudbe);
                    }

                    Posudbe.Save(path);

                }
                ListaPosudbaKnjiga.Clear();
                this.Close();
            }
            txtBxIdKnjige.Text = "";
            txtBxIdKorisnika.Text = "";
            

        }

    }

        }

