﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using System.IO;
using System.Collections;

namespace AplikacijaBiblioteka
{
    public partial class UpisKnjiga : Form
    {
        static List<Knjige> ListaKnjiga = new List<Knjige>();
        static string pathdocuments = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
        static string xmlfile = "Knjige.xml";
        static string path = Path.Combine(pathdocuments, xmlfile);


        public UpisKnjiga()
        {
            InitializeComponent();
        }

        private void btnUpisKnj_Click(object sender, EventArgs e)
        {

            Knjige UpisKnjige = new Knjige(Convert.ToInt32(txtBxIdKnj.Text), txtBxNazivKnj.Text, txtBxAutorKnj.Text);
            ListaKnjiga.Add(UpisKnjige);
            DialogResult dialogResult = MessageBox.Show("Želite li napraviti još jedan upis?", "Upis", MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.No)
            {
                try
                {
                    var Knjige = XDocument.Load(path);
                    foreach (Knjige knjige in ListaKnjiga)
                    {
                        var Knjiga = new XElement("Korisnik",
                            new XElement("ID", knjige.ID1),
                            new XElement("Naziv", knjige.Naziv1),
                            new XElement("Autor", knjige.Autor1));
                        Knjige.Root.Add(Knjiga);

                    }
                    Knjige.Save(path);
                }
                catch (Exception ex)
                {
                    var Knjige = new XDocument();
                    Knjige.Add(new XElement("Knjige"));
                    foreach (Knjige knjiga in ListaKnjiga)
                    {
                        var Knjiga = new XElement("Knjiga",
                        new XElement("ID", knjiga.ID1),
                        new XElement("Naziv", knjiga.Naziv1),
                        new XElement("Autor", knjiga.Autor1));
                        Knjige.Root.Add(Knjiga);
                    }

                    Knjige.Save(path);

                }
                ListaKnjiga.Clear();
                this.Close();
            }
            txtBxIdKnj.Text = "";
            txtBxNazivKnj.Text = "";
            txtBxAutorKnj.Text = "";

        }

        private void UpisKnjiga_Load(object sender, EventArgs e)
        {

        }
    }
}
